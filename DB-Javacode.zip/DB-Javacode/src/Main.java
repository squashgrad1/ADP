import java.sql.*;

public class Main {
    public static void main(String[] args) {



/**
        UI.init();
        while(true){
            UI.printMenu();
            switch(UI.waitForInput()){
                case 1:{
                    System.out.println("Schiff eingefuegt");
                    break;
                }
                case 2:{
                    System.out.println("Schiffe gefiltert");
                    break;
                }
                case 3:{
                    System.out.println("Reise ausgegeben");
                    break;
                }
                case 4:{
                    UI.closeUI();
                    System.exit(0);
                }
                default: {
                    System.out.println("ungueltige Eingabe");
                    break;
                }
            }
        }
 */
    }
}
