public class Schiff {
    private String imoNr;
    private int teu;
    private int baujahr;

}
